module com.stockmarket.model {
    exports com.stockmarket.model;
}