package com.stockmarket.main;

import com.stockmarket.model.Asset;
import com.stockmarket.model.Bond;
import com.stockmarket.portfolio.PortfolioPosition;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class StockMarketSimStage1 {    //obecnie martwy kod, do usuniecia
    private double cash;
    private Map<String, PortfolioPosition> positionMap;

    public void Portfolio(double initialCash) {
        this.cash = initialCash;
        this.positionMap = new HashMap<>();
    }

    public StockMarketSimStage1(Map<String, PortfolioPosition> positions)
    {
        positionMap = positions;
    }

    public void addAsset(Asset asset, int quantity) {
        if (asset == null || quantity <= 0) {
            throw new IllegalArgumentException("Nieprawidłowy asset lub ilość.");
        }

        String symbol = asset.getSymbol();

        if (positionMap.containsKey(symbol))
        {
            var newQty = positionMap.get(symbol).quantity() + quantity;
            positionMap.put(symbol, new PortfolioPosition(asset, newQty));
        }
        else
        {
            positionMap.put(symbol, new PortfolioPosition(asset, quantity));
        }

        cash -= quantity * asset.getCurrentPrice();
    }

    public void Test(){
        var asset1 = new Bond("T", "Test", 1.0, 0.10);
        var asset2 = new Bond("T1", "Test1", 1.0, 0.10);


        /// ,,,,awdkajwd

        var priceIOfAsset1 = asset1.getCurrentPrice();

        if(asset1 == asset2){

        }
    }

    public double calculateAssetValue() { //wartosc akcji, wszystkiej pozycji
        double total = 0.0;
        for (PortfolioPosition pos : positionMap.values()) {
            total += pos.asset().getCurrentPrice() * pos.quantity();
        }

        for( int i = 0; i < positionMap.size(); i++ )  //to samo co u gory
        {
           var pos = positionMap.get(positionMap.get(i));
           total += pos.asset().getCurrentPrice() * pos.quantity();
        }

        return total;
    }

    public double calculateTotalValue() {
        return cash + calculateAssetValue();
    }

    public double getCash() {
        return cash;
    }

    public Map<String, PortfolioPosition> getPositionMap() {
        return Collections.unmodifiableMap(positionMap);
    }
}