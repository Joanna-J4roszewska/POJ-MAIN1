package com.stockmarket.main;

import com.stockmarket.model.Asset;
import com.stockmarket.model.Bond;
import com.stockmarket.model.Stock;
import com.stockmarket.portfolio.Portfolio;
import com.stockmarket.portfolio.PortfolioPosition;
import com.stockmarket.portfolio.PortfolioService;
import com.stockmarket.portfolio.persistence.CsvConfig;
import com.stockmarket.portfolio.persistence.FilePortfolioRepository;
import com.stockmarket.portfolio.persistence.PortfolioRepository;
import com.stockmarket.ui.ConsoleUI;

import java.time.Month;
import java.time.format.TextStyle;
import java.util.*;

public class StockMarketSimStage2 {
    public static void main(String[] args) {
        PortfolioRepository repo = new FilePortfolioRepository();
        PortfolioService service = new PortfolioService(repo);
        CsvConfig csvConfig = new CsvConfig();
        csvConfig.initializeAssetsCsvIfNotExists();
        PortfolioService portfolioService
        ConsoleUI ui = new ConsoleUI(portfolioService, market);
        ui.start();

        service.loadPortfolio();
        List<Asset> marketAssets = new ArrayList<>();
        marketAssets.add(new Stock("CDR", "CD Projekt", 90.0));
        marketAssets.add(new Stock("PKO", "PKO BP", 40.0));
        marketAssets.add(new Bond("POL10", "Obligacja Skarbowa 10-letnia", 100.0, 0.02));
        marketAssets.add(new Stock("ZLA", "ZLA BP", 40.0) );

        Portfolio portfolio = new Portfolio(10000.0);


        portfolio.addAsset(marketAssets.get(0), 10);
        portfolio.addAsset(marketAssets.get(1), 50);
        portfolio.addAsset(marketAssets.get(2), 5);
        portfolio.addAsset(marketAssets.get(3), 10);
        portfolio.addAsset(marketAssets.get(0), 7);
        portfolio.addAsset(marketAssets.get(3), 20);
        // 4. Symulacja rynku
        for (int i = 0; i < 12; i++) {
            MonthlyUpdate(marketAssets, portfolio, i+1);

        }

        // 5. Wyświetlenie końcowego stanu portfela
            PrintPortfolioInfo(portfolio);
    }

    public static void PrintPortfolioInfo(Portfolio portfolio) {
        System.out.println("=== KOŃCOWY STAN PORTFELA ===");
        System.out.printf("Gotówka: %.2f PLN%n", portfolio.getCash());
        for (var entry : portfolio.getPositions().entrySet()) {
            var pos = entry.getValue();
            var asset = pos.asset(); //aktyw9
            var qty = pos.quantity();
            double value = (double) qty * asset.getCurrentPrice();
            System.out.printf("%s (%s): %d × %.2f PLN = %.2f PLN%n",
                    asset.getSymbol(), asset.getName(), qty, asset.getCurrentPrice(), value);
        }
        System.out.printf("Łączna wartość: %.2f PLN%n", portfolio.calculateTotalValue());
    }

    public static void MonthlyUpdate(List<Asset> marketAssets, Portfolio portfolio, int monthNumber) {
        // Aktualizacja cen aktywów
        for (Asset asset : marketAssets) {
            asset.updatePrice();
        }

        var monthName = Month.of(monthNumber).getDisplayName(TextStyle.FULL_STANDALONE, new Locale("PL")); //standalone, nieodmienne koncowki

        // Obliczanie i wyświetlanie wartości portfela
        double totalValue = portfolio.calculateTotalValue();
        System.out.printf("Krok %s: Wartość portfela = %.2f PLN%n", monthName, totalValue);

        for (PortfolioPosition portfolioPosition : new ArrayList<>(portfolio.getPositions().values())) {
            var asset = portfolioPosition.asset();
            System.out.printf("  %s (%s): %.2f PLN%n", asset.getSymbol(), asset.getName(), asset.getCurrentPrice());
        }
        System.out.println();
    }
}