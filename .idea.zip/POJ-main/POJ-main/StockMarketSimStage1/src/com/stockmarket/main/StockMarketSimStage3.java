package com.stockmarket.main;
import com.stockmarket.market.Market;
import com.stockmarket.model.Asset;
import com.stockmarket.portfolio.Portfolio;
import com.stockmarket.portfolio.persistence.CsvAssetRepository;
import java.io.IOException;
import java.util.Map;
import java.util.Optional;
import static com.stockmarket.main.StockMarketSimStage2.MonthlyUpdate;
import static com.stockmarket.main.StockMarketSimStage2.PrintPortfolioInfo;

public class StockMarketSimStage3 {
    public static void main(String[] args) {
        String path = "assets.csv"; // ścieżka do pliku CSV
        CsvAssetRepository repo = new CsvAssetRepository(path);

        try {
            Map<String, Asset> assets = repo.loadAssetDefinitions();
            assets.forEach((symbol, asset) -> {
                System.out.println(symbol + ": " + asset.getName() + ", cena: " + asset.getCurrentPrice());
            });

            // Tworzymy Market z repozytorium
            var market = new Market(repo);

            Optional<Asset> asset = market.getAsset("AAPL");
            asset.ifPresent(a -> System.out.println("Znaleziono: " + a.getName() + ", cena: " + a.getCurrentPrice()));

            var portfolio = new Portfolio(200000);

            BuyWithCatchException("POL10", 10, portfolio, market);
            BuyWithCatchException("TFI", 6, portfolio, market);
            BuyWithCatchException("CDR", 12, portfolio, market);
            BuyWithCatchException("BDA", 100, portfolio, market);
            BuyWithCatchException("ZZZZ", 10, portfolio, market);

            // 4. Symulacja rynku
            for (int i = 0; i < 12; i++) {
                MonthlyUpdate(market.getAllAssets().values().stream().toList(), portfolio, i + 1);
            }

            PrintPortfolioInfo(portfolio);

        } catch (IOException e) {
            System.err.println("Błąd odczytu pliku CSV: " + e.getMessage());
        }
    }

    private static void BuyWithCatchException(String symbol, int quantity, Portfolio sourcePortfolio, Market market) {
        try {
            sourcePortfolio.buy(symbol, quantity, market);
        } catch (Exception e) {
            System.out.println(e.getMessage() + " " + symbol);
        }
    }
}