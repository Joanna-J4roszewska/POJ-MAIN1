module com.stockmarket.main {
    requires com.stockmarket.model;
    requires com.stockmarket.market;
    requires com.stockmarket.portfolio;
    requires com.stockmarket.persistence;
    requires com.stockmarket.ui;
    exports com.stockmarket.main;
}