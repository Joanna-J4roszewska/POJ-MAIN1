package com.stockmarket.portfolio.persistence;

import com.stockmarket.portfolio.Portfolio;

import java.util.Optional;

public interface PortfolioRepository {
    void save(Portfolio portfolio);
    Optional<Portfolio> load();
}