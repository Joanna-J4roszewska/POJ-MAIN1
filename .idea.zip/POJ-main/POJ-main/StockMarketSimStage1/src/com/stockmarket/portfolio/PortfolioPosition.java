package com.stockmarket.portfolio;

import com.stockmarket.model.Asset;


public record PortfolioPosition(Asset asset, int quantity) { //przechowuje dane, tworzy gettery settery, pola, equals, hascodes itp itd w record, nie dzieciczy sie po record, TYLKO przechowywuje
    public PortfolioPosition {
        if (asset == null) {
            throw new IllegalArgumentException("com.stockmarket.model.Bond.Asset nie może być null.");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Ilość musi być dodatnia.");
        }

    }
} //zrefaktoryzowanie klasy to zmiana kodu, zmiana architektury tak by byl bardziej czytelny, mniej powtorek, itp id