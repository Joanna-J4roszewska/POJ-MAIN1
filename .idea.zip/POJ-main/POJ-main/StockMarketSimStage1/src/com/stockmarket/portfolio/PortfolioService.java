package com.stockmarket.portfolio;

import com.stockmarket.portfolio.persistence.PortfolioRepository;

import java.util.Optional;

public class PortfolioService {

    private final PortfolioRepository portfolioRepository;
    private Portfolio portfolio;


    public PortfolioService(PortfolioRepository portfolioRepository) {
        this.portfolioRepository = portfolioRepository;
        this.portfolio = new Portfolio(0.0);
    }


    public void loadPortfolio() {
        Optional<Portfolio> loaded = portfolioRepository.load();
        if (loaded.isPresent()) {
            portfolio = loaded.get();
            System.out.println("Portfolio loaded");
        } else {
            System.out.println("No saved portfolio found, using empty portfolio");
        }
    }


    public void savePortfolio() {
        portfolioRepository.save(portfolio);
        System.out.println("Portfolio saved");
    }


    public void addCash(double amount) {
        if (amount > 0) {
            double newCash = portfolio.getCash() + amount;
             portfolio = new Portfolio(newCash);
            System.out.println("Added cash: " + amount);
        }
    }

    public Portfolio getPortfolio() {
        return portfolio;
    }

    public void save() {
    }

    public void load() {
    }

    public void sell(String symbol, int quantity) {
    }

    public void buy(String symbol, int quantity) {
    }
}