package com.stockmarket.portfolio;

import com.stockmarket.exception.AssetNotFoundException;
import com.stockmarket.exception.InsufficientFundsException;
import com.stockmarket.market.Market;
import com.stockmarket.market.Tradable;
import com.stockmarket.model.Asset;
import com.stockmarket.model.Bond;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Portfolio {
    private double cash;
    private Map<String, PortfolioPosition> positions;

    public Portfolio(double initialCash) {
        if (initialCash < 0) {
            throw new IllegalArgumentException("Cash cannot be negative.");
        }
        this.cash = initialCash;
        this.positions = new HashMap<>();
    }
//dodaj ze nie moze byc ujemne
    public double getCash() {
        return cash;
    }

    public void addAsset(Asset asset, int quantity) {
        var symbol = asset.getSymbol();
        if (positions.containsKey(symbol)){
            var portfolioPosition = positions.get(symbol);
            positions.put(symbol, new PortfolioPosition(asset, quantity + portfolioPosition.quantity()));
        }
        else {
            positions.put(symbol, new PortfolioPosition(asset, quantity));
        }
    }

    private void removeAsset(Asset asset, int quantity) {
        var portfolioPosition = positions.get(asset.getSymbol());
        if(portfolioPosition.quantity() < quantity){
            positions.put(asset.getSymbol(), new PortfolioPosition(asset, portfolioPosition.quantity() - quantity));
        }
        else
            positions.remove(asset.getSymbol());

    }

    public Map<String, PortfolioPosition> getPositions()
    {
        return Collections.unmodifiableMap(positions);
    }

    public double calculateAssetValue() {
        double totalValue = 0.0;
        for (PortfolioPosition pos: positions.values()) { //iteracja po kazdym elemencie kolekcji, suma wartosc wszystkich elementow kolekcji
            totalValue += pos.asset().getCurrentPrice() * pos.quantity(); //dla kazdego elementu kolekcji, cena razy wartosc dla kazdego portfolio position, jakie sie znajdzie
        }
        return totalValue;
    }

    public double calculateTotalValue()
    {
        return calculateAssetValue() + getCash();
    }

    public void buy(String symbol, int quantity, Market market) throws InsufficientFundsException, AssetNotFoundException
    {
        var assetOptional = market.getAsset(symbol);
        if(assetOptional.isEmpty()){
            throw new AssetNotFoundException("Asset not found");
        }
        var asset = assetOptional.get();

         ThrowExceptionIfAssetNotTradable(asset);
         var currentPrice = ((Tradable)asset).getCurrentPrice();

         if(cash < currentPrice*quantity){
             throw new InsufficientFundsException("Insufficient funds");
         }

         cash -= currentPrice * quantity;
         addAsset(asset, quantity);

         System.out.println("Buy successful:" + symbol + " quantity:" + quantity );
    }

    private void ThrowExceptionIfAssetNotTradable(Asset asset) {
        if(!(asset instanceof Tradable)){
            throw new IllegalArgumentException("Given asset is not Tradable");
        }
    }

    public void sell(String symbol, int quantity, Market market) throws InsufficientFundsException, AssetNotFoundException
    {
         if(!this.getPositions().containsKey(symbol))
             throw new AssetNotFoundException("Asset not found");

         var position = this.getPositions().get(symbol);
         if(position.quantity() < quantity){
             throw new InsufficientFundsException("Insufficient funds");
         }

         var marketAssetOptional = market.getAsset(symbol);
         if(marketAssetOptional.isEmpty()){
             throw new AssetNotFoundException("Asset not found on market");
         }

         var asset = marketAssetOptional.get();
         ThrowExceptionIfAssetNotTradable(asset);

         cash += quantity * asset.getCurrentPrice();
         removeAsset(asset, quantity);

        System.out.println("Sell successful:" + symbol + " quantity:" + quantity );
    }



}