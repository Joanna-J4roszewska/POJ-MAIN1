module com.stockmarket.portfolio {
    requires com.stockmarket.model;
    requires com.stockmarket.market;
    exports com.stockmarket.portfolio;
}