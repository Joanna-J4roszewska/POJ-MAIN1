module com.stockmarket.persistence {
    requires com.stockmarket.model;
    requires com.stockmarket.portfolio;
    requires com.stockmarket.market;
    requires com.fasterxml.jackson.databind; // dla Jacksona
    requires com.opencsv;                     // jeśli używasz OpenCSV
    requires java.base; // nie zawsze potrzebne, bo to domyślne
    exports com.stockmarket.portfolio.persistence;
}