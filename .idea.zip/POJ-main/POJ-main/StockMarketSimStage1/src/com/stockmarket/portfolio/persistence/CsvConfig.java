package com.stockmarket.portfolio.persistence;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CsvConfig {

    // Ścieżka do pliku assets.csv
    private static final String ASSETS_CSV_PATH = "assets.csv";

    public String getAssetsCsvPath() {
        return ASSETS_CSV_PATH;
    }

    public void initializeAssetsCsvIfNotExists() {
        File file = new File(ASSETS_CSV_PATH);
        if (!file.exists()) {
            System.out.println("Plik " + ASSETS_CSV_PATH + " nie istnieje. Tworzę domyślny plik assets.csv...");
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("symbol,name,type,initial_price");
                writer.newLine();
                writer.write("AAPL,Apple Inc.,Stock,150.00");
                writer.newLine();
                writer.write("GOOG,Alphabet Inc.,Stock,2800.00");
                writer.newLine();
                writer.write("TBOND,Treasury Bond,Bond,1000.00");
                writer.newLine();
                System.out.println("Plik assets.csv został utworzony.");
            } catch (IOException e) {
                System.err.println("Błąd przy tworzeniu pliku assets.csv: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            System.out.println("Plik assets.csv już istnieje pod ścieżką: " + ASSETS_CSV_PATH);
        }
    }
}