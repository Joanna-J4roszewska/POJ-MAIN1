package com.stockmarket.portfolio.persistence;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stockmarket.portfolio.Portfolio;
import java.io.File;
import java.io.IOException;
import java.util.Optional;

public class FilePortfolioRepository implements PortfolioRepository {

    private static final String FILE_PATH = "portfolios.json";
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final File file = new File(FILE_PATH);


    @Override
    public void save(Portfolio portfolio) {
        try {
            objectMapper.writeValue(file, portfolio);
            System.out.println("Saved " + file.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error saving: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public Optional<Portfolio> load() {
        if (!file.exists()) {
            System.out.println("File not found");
            return Optional.empty();
        }
        try {
            Portfolio portfolio = objectMapper.readValue(file, Portfolio.class);
            System.out.println("Loaded " + portfolio);
            return Optional.of(portfolio);
        } catch (IOException e) {
            System.err.println("Error loading: " + e.getMessage());
            e.printStackTrace();
            return Optional.empty();
        }
    }
}