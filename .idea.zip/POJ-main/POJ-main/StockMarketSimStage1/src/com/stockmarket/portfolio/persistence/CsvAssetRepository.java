package com.stockmarket.portfolio.persistence;

import com.stockmarket.model.Asset;
import com.stockmarket.model.Bond;
import com.stockmarket.model.Stock;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CsvAssetRepository implements AssetRepository {

    private final String csvFilePath;

    public CsvAssetRepository(String csvFilePath) {
        this.csvFilePath = csvFilePath;
    }

    @Override
    public Map<String, Asset> loadAssetDefinitions() throws IOException {
        Map<String, Asset> assets = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            String line = br.readLine(); // czytamy nagłówek

            while ((line = br.readLine()) != null) {

                String[] parts = line.split(",");

                if (parts.length < 4) {
                    System.err.println("Niepoprawny wiersz CSV: " + line);
                    continue;
                }

                String symbol = parts[0].trim();
                String name = parts[1].trim();
                String type = parts[2].trim().toLowerCase();
                double initialPrice;

                try {
                    initialPrice = Double.parseDouble(parts[3].trim());
                } catch (NumberFormatException e) {
                    System.err.println("Niepoprawna cena początkowa: " + parts[3]);
                    continue;
                }

                Asset asset;
                if ("stock".equals(type)) {
                    asset = new Stock(symbol, name, initialPrice);
                } else if ("bond".equals(type)) {

                    asset = new Bond(symbol, name, initialPrice, 0.02);
                } else {
                    System.err.println("Nieznany typ aktywa: " + type);
                    continue; // pomijamy wiersz
                }

                assets.put(symbol, asset);
            }
        }

        return assets;
    }
}
