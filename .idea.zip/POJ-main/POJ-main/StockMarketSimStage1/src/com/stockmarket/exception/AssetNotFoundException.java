package com.stockmarket.exception;

public class AssetNotFoundException extends Exception
{
    public AssetNotFoundException(String message)
    {
        super(message);
    }
}
