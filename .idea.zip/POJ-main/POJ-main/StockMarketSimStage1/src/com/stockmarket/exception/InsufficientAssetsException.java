package com.stockmarket.exception;

public class InsufficientAssetsException extends Exception
{
    public InsufficientAssetsException(String message)
    {
        super(message);
    }
}
