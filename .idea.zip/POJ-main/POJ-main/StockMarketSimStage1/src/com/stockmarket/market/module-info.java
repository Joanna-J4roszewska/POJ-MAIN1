module com.stockmarket.market {
    requires com.stockmarket.model;
    exports com.stockmarket.market;
}