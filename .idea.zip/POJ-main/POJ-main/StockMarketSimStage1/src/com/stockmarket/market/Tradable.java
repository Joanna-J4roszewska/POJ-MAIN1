package com.stockmarket.market;

public interface Tradable {
    String getSymbol();            // Zwraca symbol handlowy (np. "AAPL")
    double getCurrentPrice();     // Zwraca aktualną cenę
}
