package com.stockmarket.market;

import com.stockmarket.model.Asset;
import com.stockmarket.portfolio.persistence.AssetRepository;

import java.io.IOException;
import java.util.*;

public class Market {

    private Map<String, Asset> assetMap;


    public Market(AssetRepository assetRepository) {
        try {
            this.assetMap = assetRepository.loadAssetDefinitions();
        } catch (IOException e) {
            System.err.println("Błąd podczas ładowania assetów: " + e.getMessage());
            this.assetMap = new HashMap<>();
        }
    }

    public Optional<Asset> getAsset(String symbol) {
        return Optional.ofNullable(assetMap.get(symbol));
    }

    public void updatePrices() {
        for (Asset asset : assetMap.values()) {
            asset.updatePrice();
        }
    }

    public Map<String, Asset> getAllAssets() {
        return Collections.unmodifiableMap(assetMap);
    }

    public void addAsset(Asset asset) {
        assetMap.put(asset.getSymbol(), asset);
    }

    public double getPrice(String symbol) {
        Asset asset = assetMap.get(symbol);
        return asset.getCurrentPrice();
    }

    public void simulatePriceChanges() {
        Random rand = new Random();
        for (Asset asset : assetMap.values()) {
            double change = (rand.nextDouble() * 2 - 1) * 0.1; // +/-10%
            double newPrice = asset.getCurrentPrice() * (1 + change);
            asset.updatePrice();
        }
    }

    public boolean containsAsset(String symbol) {
        return assetMap.containsKey(symbol);
    }

    public Set<String> getAvailableSymbols() {
        return assetMap.keySet();
    }
}