package com.stockmarket.model;

import com.stockmarket.market.Tradable;

public class Stock extends Asset implements Tradable {

    public Stock(String symbol, String name, double initialPrice) {
        super(symbol, name, initialPrice);
    }
@Override
public String getSymbol() {
        return symbol;
}
@Override
public double getCurrentPrice() {
        return currentPrice;
}
    @Override
    public void updatePrice() {
        double changeFactor = 1.0 + (Math.random() - 0.5) * 0.1; // +/- 5%
        currentPrice *= changeFactor;
        if (currentPrice < 0.01) {
            currentPrice = 0.01;
        }
    }
}

