package com.stockmarket.model;

public class Bond extends Asset {
    private final double interestRate; // np. 0.02 oznacza 2% rocznie


    public Bond(String symbol, String name, double initialPrice, double interestRate) {
        super(symbol, name, initialPrice);
        if (interestRate < 0) {
            throw new IllegalArgumentException("Oprocentowanie nie może być ujemne.");
        }
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    @Override
    public void updatePrice() {
        // Symulacja wzrostu wartości obligacji z uwzględnieniem odsetek, np. miesięcznych
        currentPrice += ((currentPrice * interestRate) / 12); // np. 2% rocznie -> ~0.166% miesięcznie
    }
}