package com.stockmarket.model;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import java.util.Objects;


@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Bond.class, name = "bond"),
        @JsonSubTypes.Type(value = Stock.class, name = "stock")
})

public abstract class Asset {
    protected final String symbol;
    protected final String name;
    protected double currentPrice;
    protected double initialPrice;

    public Asset(String symbol, String name, double initialPrice) {
        this.symbol = symbol;
        this.name = name;
        this.initialPrice = initialPrice;
        this.currentPrice = initialPrice;
        if (symbol == null || name == null || initialPrice < 0) {
            throw new IllegalArgumentException("Invalid asset symbol");
        }
    }

    public String getSymbol() {
        return symbol;
    }

    public String getName() {
        return name;
    }

    public double getCurrentPrice() {
        return currentPrice;
    }

    public double getInitialPrice() {
        return initialPrice;
    }

    public abstract void updatePrice();

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false; //czy nie jest typem tej klasy w ktorej jest wykonywana metoda
        Asset other = (Asset) obj;
        return Objects.equals(this.symbol, other.symbol); //ten obiekt porownywany z tym wejsciowym
    }

    @Override
    public int hashCode() {
        return Objects.hash(symbol);
    }


}