package com.stockmarket.ui;

import com.stockmarket.market.Market;
import com.stockmarket.model.Asset;
import com.stockmarket.portfolio.Portfolio;
import com.stockmarket.portfolio.PortfolioService;

import java.util.Map;
import java.util.Scanner;

public class ConsoleUI {

    private final PortfolioService portfolioService;
    private final Market market;
    private final Scanner scanner;

    public ConsoleUI(PortfolioService portfolioService, Market market) {
        this.portfolioService = portfolioService;
        this.market = market;
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        boolean running = true;

        while (running) {
            displayMenu();
            System.out.print("Wybierz opcję: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> displayMarket();
                case "2" -> displayPortfolio();
                case "3" -> handleBuyAction();
                case "4" -> handleSellAction();
                case "5" -> handleSaveAction();
                case "6" -> handleLoadAction();
                case "0" -> {
                    System.out.println("Zamykanie aplikacji...");
                    running = false;
                }
                default -> System.out.println("Nieznana opcja, spróbuj ponownie.");
            }
        }
    }

    private void displayMenu() {
        System.out.println("\n=== MENU GŁÓWNE ===");
        System.out.println("1. Wyświetl dostępne aktywa");
        System.out.println("2. Wyświetl portfel");
        System.out.println("3. Kup aktywo");
        System.out.println("4. Sprzedaj aktywo");
        System.out.println("5. Zapisz portfel do pliku");
        System.out.println("6. Wczytaj portfel z pliku");
        System.out.println("0. Wyjście");
    }

    private void displayMarket() {
        System.out.println("\n=== DOSTĘPNE AKTYWA NA RYNKU ===");
        for (Map.Entry<String, Asset> entry : market.getAllAssets().entrySet()) {
            Asset asset = entry.getValue();
            System.out.println(asset.getSymbol() + " | " + asset.getName() + " | cena: " + asset.getCurrentPrice());
        }
    }

    private void displayPortfolio() {
        Portfolio portfolio = portfolioService.getPortfolio();
        System.out.println("\n=== TWÓJ PORTFEL ===");
        System.out.println("Gotówka: " + portfolio.getCash());
        System.out.println("Pozycje: " + portfolio.getPositions());
    }

    private void handleBuyAction() {
        System.out.print("Podaj symbol aktywa do kupienia: ");
        String symbol = scanner.nextLine();
        System.out.print("Podaj ilość: ");
        int quantity = Integer.parseInt(scanner.nextLine());

        try {
            portfolioService.buy(symbol, quantity);
            System.out.println("Zakupiono " + quantity + " sztuk " + symbol);
        } catch (Exception e) {
            System.out.println("Błąd zakupu: " + e.getMessage());
        }
    }

    private void handleSellAction() {
        System.out.print("Podaj symbol aktywa do sprzedaży: ");
        String symbol = scanner.nextLine();
        System.out.print("Podaj ilość: ");
        int quantity = Integer.parseInt(scanner.nextLine());

        try {
            portfolioService.sell(symbol, quantity);
            System.out.println("Sprzedano " + quantity + " sztuk " + symbol);
        } catch (Exception e) {
            System.out.println("Błąd sprzedaży: " + e.getMessage());
        }
    }

    private void handleSaveAction() {
        try {
            portfolioService.save();
            System.out.println("Portfel zapisany pomyślnie.");
        } catch (Exception e) {
            System.out.println("Błąd zapisu: " + e.getMessage());
        }
    }

    private void handleLoadAction() {
        try {
            portfolioService.load();
            System.out.println("Portfel wczytany pomyślnie.");
        } catch (Exception e) {
            System.out.println("Błąd wczytywania: " + e.getMessage());
        }
    }
}